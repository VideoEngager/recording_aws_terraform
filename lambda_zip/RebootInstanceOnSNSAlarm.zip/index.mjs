import { 
    ElasticLoadBalancingV2Client, 
    DescribeTargetHealthCommand 
} from "@aws-sdk/client-elastic-load-balancing-v2";
import { 
    EC2Client, 
    RebootInstancesCommand 
} from "@aws-sdk/client-ec2";

// Initialize AWS Clients outside the handler for connection reuse
const elbClient = new ElasticLoadBalancingV2Client({});
const ec2Client = new EC2Client({});

// Retrieve the Target Group ARN from Environment Variables
const TARGET_GROUP_ARN = process.env.TARGET_GROUP_ARN;

export const handler = async (event, context) => {
    // Fail fast if the environment variable is missing
    if (!TARGET_GROUP_ARN) {
        console.error("Configuration Error: TARGET_GROUP_ARN environment variable is not set.");
        return;
    }

    // Iterate over all SNS records in the event
    for (const record of event.Records) {
        await processRecord(record, context);
    }
};

const processRecord = async (record, context) => {
    console.log(`Processed record : ${JSON.stringify(record)}`);

    try {
        // Parse the SNS message payload
        const snsMessage = JSON.parse(record.Sns.Message);

        const oldState = snsMessage.OldStateValue;
        const newState = snsMessage.NewStateValue;

        console.log(`Processed alarm fromState : ${oldState} , toState : ${newState} , targetGroup (EnvVar) : ${TARGET_GROUP_ARN}`);

        // Check if the alarm transitioned from OK to ALARM
        if (oldState === "OK" && newState === "ALARM") {
            
            // 1. Describe the health of the targets using the ARN from the environment variable
            const describeHealthCommand = new DescribeTargetHealthCommand({
                TargetGroupArn: TARGET_GROUP_ARN
            });
            const healthResponse = await elbClient.send(describeHealthCommand);

            // 2. Find unhealthy instances
            const unhealthyTargets = healthResponse.TargetHealthDescriptions.filter(
                t => t.TargetHealth.State === "unhealthy"
            );

            // 3. Collect Instance IDs to reboot
            const instanceIdsToReboot = [];
            for (const brokenInstance of unhealthyTargets) {
                console.log(`REBOOTING : InstanceId : ${brokenInstance.Target.Id} , State : ${brokenInstance.TargetHealth.State} , Description : ${brokenInstance.TargetHealth.Description}`);
                instanceIdsToReboot.push(brokenInstance.Target.Id);
            }

            // 4. Execute EC2 Reboot
            if (instanceIdsToReboot.length > 0) {
                const rebootCommand = new RebootInstancesCommand({
                    InstanceIds: instanceIdsToReboot
                });
                await ec2Client.send(rebootCommand);
                console.log(`Successfully sent reboot request for instances: ${instanceIdsToReboot.join(', ')}`);
            } else {
                console.log("Alarm triggered, but no instances were currently in an 'unhealthy' state.");
            }
        }
    } catch (error) {
        console.error("Error processing SNS record:", error);
    }
};